2 hours

I struggled a little with creating the UML diagram. I had to look up some of the symbols and what they meant.

No real shortcomings on my answeres that I am currently aware of.