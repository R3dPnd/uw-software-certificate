1. 1hr
2. none
3. The program has to check each number and do the full calculation. This becomes very costly as n increases.
4a.

Welcome to the Armstrong number calculator.
Please enter an integer from 10 through 100,000,000 (without the commas):Extra credit pls
Please enter a valid input
Please enter an integer from 10 through 100,000,000 (without the commas):Pretty please?
Please enter a valid input
Please enter an integer from 10 through 100,000,000 (without the commas):1.1
Please enter a valid input
Please enter an integer from 10 through 100,000,000 (without the commas):3?
Please enter a valid input
Please enter an integer from 10 through 100,000,000 (without the commas):100
The Armstrong numbers from 10 through 100 are:


The total number of Armstrong numbers found was 0

4b. O(n*m) where n is the input value and m is m the length of the input, which in this limited version is <=9, but in
theory could be any value. The solution iterates from 10 to n, where n < 100,000,000. Each number checked  It checks
each number for armstrong value which can be very costly. It checks each digit as well at each value.

