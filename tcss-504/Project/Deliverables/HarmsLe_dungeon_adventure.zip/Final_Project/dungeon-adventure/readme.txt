-what each person did and what time each person spent
-shortcomings listed if any
-extra credit considerations listed

Preston Harms
