'''
- Contains default constructor and all methods you deem necessary -- modular design is CRUCIAL
- Contains the following items/behaviors
    - (Possibly a) Healing Potion - heals 5-15 hit points (this amount will be randomly generated -- you can modify the range)(Possibly a) Pit - damage a pit can cause is from 1-20 hit points (this amount will be randomly generated - you can modify the range)
    - (Possibly an) Entrance - only one room will have an entrance and the room that contains the entrance will contain NOTHING else
    - (Possibly an) Exit - only one room will have an exit and the room that contains the exit will contain NOTHING else
    - (Possibly a) Pillar of OO - four pillars in game and they will never be in the same room
    - Doors - N, S, E, W
    - 10% possibility (this is a constant that you can modify) room will contain a healing potion, vision potion, and pit (each of these are independent of one another)
    - Vision Potion - can be used to allow user to see eight rooms surrounding current room as well as current room (location in maze may cause less than 8 to be displayed)
- Must contain a _ _ str _ _ () method that builds a 2D Graphical representation of the room (NOTE: you may use any graphical components that you wish). The (command line) representation is as follows:
    - * - * will represent a north/south door (the - represents the door). If the room is on a boundary of the maze (upper or lower), then that will be represented with ***
    - East/west doors will be represented in a similar fashion with the door being the | character as opposed to a -.
    - In the center of the room you will display a letter that represents what the room contains. Here are the letters to use and what they represent:
    - M - Multiple Items
    - X - Pit
    - i - Entrance (In)
    - O - Exit (Out)
    - V - Vision Potion
    - H - Healing Potion
    - <space> - Empty Room
    - A, E, I, P - Pillars

Example:

Room 1,1 might look like
*-*
|P |
*-*

Room 0,0 might look like
***
*E|
*-*
'''

class Room:
    def __init__(self, items, doors):
        self.items = items
        self.doors = doors
        self.east = None
        self.west = None
        self.north = None
        self.south = None

    def __str__(self):
        return f"Items: {self.items}, Doors: {self.doors}"

    def get_healing_potion(self):
        if self.items == "H":
            return True

    def get_vision_potion(self):
        pass

    def get_pit(self):
        pass

    def get_entrance(self):
        pass

    def get_exit(self):
        pass

    def get_pillar(self):
        pass

    def get_door(self):
        pass