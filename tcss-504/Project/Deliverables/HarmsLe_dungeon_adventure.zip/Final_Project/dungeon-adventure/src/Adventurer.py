'''
- Has a name
- Contains at least the following:
    - Hit Points - initially set to 75 - 100 upon creation (randomly generate - you can change the range)
    - The number of Healing Potions
    - The number of Vision Potions
    - The which Pillars found
    - Ability to move in Dungeon (you might decide to place this behavior elsewhere)
    - Increases or decreases the Hit Points accordingly
- Contains a _ _ str _ _ () method that builds a String containing:
    - Name
    - Hit Points
    - Total Healing Potions
    - Total Vision Potions
    - List of Pillars Pieces Found
'''

class Adventurer:
    def __init__(self, name, hit_points, strength):
        self.name = name
        self.hit_points = hit_points
        self.strength = strength
        self.healing_potions = 0
        self.vision_potions = 0
        self.pillars = []

    def __str__(self):
        return f"Name: {self.name}, Hit Points: {self.hit_points}, Strength: {self.strength}"


    def increase_hit_points(self, hit_points):
        self.hit_points += hit_points

    def decrease_hit_points(self, hit_points):
        self.hit_points -= hit_points

    def get_hit_points(self):
        return self.hit_points

    def get_healing_potions(self):
        return self.healing_potions

    def get_vision_potions(self):
        return self.vision_potions
    
    def find_pillar(self, pillar):
        self.pillars.append(pillar)

    def get_pillars(self):
        return self.pillars