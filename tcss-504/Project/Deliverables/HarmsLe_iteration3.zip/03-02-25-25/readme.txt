Preston: I had some fun figuring out the testing and validation for the sqlite implimentation
Richard: Worked hard to get the GUI up and running 