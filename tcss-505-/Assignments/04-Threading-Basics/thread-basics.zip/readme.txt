I didn't have many issues, though I was surprised at how little multi threads actually impacted performance.
I was expecting a much larger performance increase, but it seems that the overhead of managing threads
limits the performance gains.

